# Raport: Analiza sprzedaży samochodów (24 miesiące)

## 1. Struktura sprzedaży

- Liczba transakcji: **7,354**

- Top marki (szt.):

Mercedes      1089
Toyota        1085
Hyundai       1068
Volkswagen    1062
Kia           1039
BMW           1024
Skoda          987


## 2. Trendy miesięczne

- Średnia sprzedaż/mies.: **306.4**; odchylenie: **57.1**



![units](plots/monthly_units.png)

![revenue](plots/monthly_revenue.png)


## 3. Anomalie i outliery

- Outliery cen: 319 | Outliery marży: 323


![box_fuel](plots/price_by_fuel.png)

![scatter](plots/price_vs_mileage.png)


## 4. Czynniki wpływu

**Top cechy wpływu (cena):**

brand_Kia               27963.410752
brand_Hyundai           26182.277313
brand_Toyota            21193.238869
brand_Volkswagen        20002.382138
brand_Skoda             11812.249080
brand_other             11812.249080
year                     7853.360663
fuel_type_ev             7071.159385
brand_Mercedes           5586.877706
fuel_type_hybrid         4616.426774
mileage_km               3121.176465
transmission_manual      2270.060251
fuel_type_petrol         1109.739155
customer_type_retail      319.682985
engine_cc                 146.005751


**Top cechy wpływu (marża):**

brand_Kia               3044.394534
brand_Hyundai           2772.149366
brand_Volkswagen        1945.988272
brand_Toyota            1913.099925
brand_Skoda             1092.020400
brand_other             1092.020400
year                    1051.645773
fuel_type_ev             902.398914
brand_Mercedes           524.226955
fuel_type_hybrid         455.123796
mileage_km               428.314192
transmission_manual      188.298319
customer_type_retail     139.823864
fuel_type_petrol          53.286943
warranty_months           38.079424


## 5. Rankingi miast i kanałów

**Miasta (szt.):**

dealer_city
Warszawa    2558
Kraków      1133
Gdańsk      1101
Wrocław      911
Poznań       897
Łódź         754


**Miasta (suma marży PLN):**

dealer_city
Warszawa    11735800.45
Kraków       5077058.00
Gdańsk       4620285.35
Wrocław      4216378.90
Poznań       4083440.80
Łódź         3393467.90


**Kanały sprzedaży:**

               units      revenue  avg_margin_pct
customer_type                                    
retail          5110  159639745.0        0.144701
fleet           2244   71283523.0        0.142640


## 6. Rekomendacje

- Zwiększyć udział **automatic** w konfiguracjach popularnych modeli – koreluje dodatnio z ceną.

- Skupić marketing EV/hybrid w **Warszawie** i dużych aglomeracjach – wyższe ceny i marże.

- Dla **fleet** negocjować pakiety gwarancyjne 12–24 m-cy: poprawa marży przy umiarkowanym ryzyku.

- Wykryte miesiące anomalii zweryfikować (kampanie, brak stanów, raportowanie) i zdjąć szumy z prognoz.


## 7. Użycie AI (prompty i korekty)

[
  {
    "area": "Cleaning",
    "prompt": "Given columns engine_cc, mileage_km, price_pln, cost_pln, suggest robust rules to fix negatives, EVs, and missing values without biasing distributions.",
    "manual_edits": "Applied median imputation within (brand,fuel_type) for engine_cc; set negative cost to NaN then imputed from price*0.85."
  },
  {
    "area": "Visualization",
    "prompt": "Propose 4 plots to understand monthly trend, brand mix, fuel-price distribution and price vs mileage without using seaborn and without specifying colors.",
    "manual_edits": "Ensured each chart uses its own figure and saved with bbox_inches='tight'; simplified titles to Polish."
  },
  {
    "area": "Drivers",
    "prompt": "How to estimate feature importances for price and margin without external libs?",
    "manual_edits": "Used numpy lstsq on standardized numerics + one-hot categoricals; interpreted |beta| as importance (heuristic)."
  }
]


---
Raport wygenerowany automatycznie.
