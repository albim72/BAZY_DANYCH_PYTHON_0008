# 📊 Three Tasks — Analiza danych sprzedażowych i sportowych w Pythonie

Ten projekt prezentuje trzy niezależne zadania analityczne wykonane w Pythonie, oparte o dane z plików CSV.  
Pokazuje **jak w praktyce połączyć Pandas, Matplotlib i dobre praktyki Pythona** w jednym repozytorium.

---

## 🎯 Zakres projektu

### **ZADANIE 1 – Analiza sprzedaży**
- Wczytanie danych sprzedażowych z pliku CSV.
- Wyznaczenie **TOP 3 klientów** wg wartości zakupów.
- Podsumowanie sprzedaży dla każdego klienta.
- Zliczenie zamówień w każdej kategorii produktów.

📂 Dane wejściowe: `data/sales.csv`  
📤 Wyniki: wyświetlane w konsoli.

**Przykład outputu:**
```
[ZADANIE 1] TOP 3 klienci (sprzedaż łączna):
customer_id total_sales
CUST-105     15400.50
CUST-204     14890.75
CUST-011     14520.20

[ZADANIE 1] Liczba zamówień per kategoria:
category     order_count
Electronics  120
Sports       85
Clothing     64
```

---

### **ZADANIE 2 – Analiza wyników biegu na 10 km**
- Obliczenie statystyk opisowych:
  - średnia, mediana, minimum, maksimum, odchylenie standardowe.
- Wyznaczenie **5 najlepszych czasów**.

📂 Dane wejściowe: `data/times_10k.csv`

**Przykład outputu:**
```
[ZADANIE 2] Podsumowanie czasów 10K:
  mean: 49.26
  median: 49.28
  min: 36.25
  max: 64.57
  std: 5.10

[ZADANIE 2] Najlepsze 5 czasów 10K (min):
[36.25 37.82 37.93 38.28 38.28]
```

---

### **ZADANIE 3 – Analiza biegów według kategorii**
- Średni czas dla każdej kategorii zawodów.
- Najlepszy czas każdego zawodnika.
- Generowanie **wykresu średnich czasów** i zapis w formacie PNG.

📂 Dane wejściowe: `data/races.csv`  
📤 Wyniki: `output/race_means.png`

**Przykład outputu:**
```
[ZADANIE 3] Średnie czasy wg kategorii:
category       mean_time
Amatorzy       54.21
Półzawodowcy   47.85
Zawodowcy      39.12

[ZADANIE 3] Najlepszy czas każdego zawodnika (top 10):
runner_id  best_time
RUN-011    36.25
RUN-054    36.45
RUN-023    37.01
...
```

**Przykładowy wykres:**

![Średnie czasy wg kategorii](output/race_means.png)

---

## 🚀 Uruchomienie projektu

1. **Sklonuj repozytorium** lub pobierz pliki:
   ```bash
   git clone https://github.com/twoj-login/three_tasks.git
   cd three_tasks
   ```

2. **Utwórz wirtualne środowisko**:
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # Linux/Mac
   .venv\Scripts\activate     # Windows
   ```

3. **Zainstaluj wymagane biblioteki**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Uruchom program**:
   ```bash
   python main.py
   ```

---

## 📦 Struktura katalogów

```
three_tasks/
│
├── data/                # Dane wejściowe CSV
│   ├── sales.csv
│   ├── times_10k.csv
│   └── races.csv
│
├── output/              # Wygenerowane pliki (np. wykresy)
│
├── tasks/               # Moduły z poszczególnymi zadaniami
│   ├── sales_task.py
│   ├── times_task.py
│   └── races_task.py
│
├── main.py              # Główna logika programu
├── requirements.txt     # Lista zależności
└── README.md            # Dokumentacja projektu
```

---

## 🛠 Technologie

- **Python 3.10+**
- **Pandas** – analiza danych
- **Matplotlib** – wizualizacja
- **Pathlib** – obsługa ścieżek
- **Virtualenv** – izolacja środowiska

---

## 💡 Dlaczego ten projekt jest ciekawy?
- Łączy **trzy różne typy analiz** w jednym spójnym kodzie.
- Uczy **dobrych praktyk struktury projektu** w Pythonie.
- Pokazuje jak w prosty sposób generować **czytelne raporty i wykresy**.
- Nadaje się jako baza do rozbudowy o kolejne analizy i formaty danych.

---

## 📜 Licencja
Projekt udostępniony na licencji MIT — możesz go dowolnie rozwijać i modyfikować.

---

✍️ **Autor:** _[Marcin]_  
🏃‍♂️ **Fun fact:** Kod powstał w przerwie między treningami biegowymi.
